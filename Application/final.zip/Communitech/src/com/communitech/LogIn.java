package com.communitech;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;












import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSetMetaData;






import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LogIn extends Activity {
	EditText textUsername, textPassword;
	SQLiteOpenHelper dbhelper;
	SQLiteDatabase sdb;
	List<Object> username2 = new CopyOnWriteArrayList<Object>();
	List<Object> password2 = new CopyOnWriteArrayList<Object>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_reg);}
		public void Main(View v){
			Intent myIntent = new Intent(this, MainMenu.class);
	        startActivity(myIntent);
		String dbname = "communitech.sqlite";
		
		textUsername = (EditText) findViewById(R.id.editUsername);
		textPassword = (EditText) findViewById(R.id.editPassword);
		dbhelper = new SQLiteOpenHelper(this,dbname,null,1) {
			
			

			@Override
			public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void onCreate(SQLiteDatabase db) {
				// TODO Auto-generated method stub
			}
		};
	}
		private String md5(String string) {
			try {
		        MessageDigest md = MessageDigest.getInstance("MD5");
		        byte[] messageDigest = md.digest(string.getBytes());
		        BigInteger number = new BigInteger(1, messageDigest);
		        String md5 = number.toString(16);
		        while (md5.length() < 32)
		           md5 = "0" + md5;
		        return md5;
		        } catch (NoSuchAlgorithmException e) {
		         Log.e("MD5", e.getLocalizedMessage());
			return null;
		        }
		}
	
	public void log(View v){
		try {
            Connection con = (Connection) ConnectionClass.CONN();
            if (con == null) {
                Toast.makeText(LogIn.this,"Error in connection with SQL server", Toast.LENGTH_SHORT).show();
            } else {
                String query = "SELECT * FROM userprofile";
                PreparedStatement stmt = (PreparedStatement) con.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();
                ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
                while(rs.next()) {
                    username2.add(rs.getString("username"));
                    password2.add(rs.getString("userpassword"));
                }
                if(username2.contains(textUsername.getText().toString()) && password2.contains(md5(textPassword.getText().toString()))){
                    String text = textUsername.getText().toString();
                    SharedPreferences sp = getSharedPreferences("login",MODE_PRIVATE);
                    SharedPreferences.Editor edit = sp.edit();
                    edit.putString("uname",text);
                    edit.commit();
                    Toast.makeText(LogIn.this, "Thank You!, Login Successful.", Toast.LENGTH_SHORT).show();
                    Intent myIntent = new Intent(this, MainMenu.class);
                    myIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(myIntent);
                }
                else if(textUsername.getText().toString().isEmpty() || textPassword.getText().toString().isEmpty()){
                	Toast.makeText(LogIn.this, "Please fill up all the fields!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(LogIn.this,"Invalid Credentials!",  Toast.LENGTH_SHORT).show();
                }
            }
        }
        catch (Exception ex)
        {
            Toast.makeText(LogIn.this,"Exception: "+ex, Toast.LENGTH_SHORT).show();
        }	}

	
	public void login(View v){
		Intent myIntent = new Intent(this, MainMenu.class);
        startActivity(myIntent);
	}
}
	
