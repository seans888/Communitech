package com.communitech;


import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ProgressBar;
import android.widget.TextView;

public class Splash extends Activity {
		private boolean backbtnPress;
		private static final int SPLASH_DURATION = 6000;
		private Handler myHandler;
		SQLiteOpenHelper dbhelper;
		SQLiteDatabase sdb;
		TextView text1;
	    Animation animFadein;
	    ProgressBar progress; 
		int pb = 0; 
		Handler h = new Handler();
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			
			// TODO Auto-generated method stub
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_loading);
			myHandler = new Handler();
			myHandler.postDelayed(new Runnable(){

				@Override
				public void run() {
					finish();	
				if(!backbtnPress){
					progress = (ProgressBar)findViewById(R.id.progressBar1);
			        new Thread(new Runnable()
			        {
			        	@Override
			        	public void run()
			        	{
			        		for(int i=0; i<100; i++)
			        		{
			        			pb+=1; 
			        			h.post(new Runnable()
			        			{
			        				public void run()
			        				{
			        					progress.setProgress(pb); 
			        					if(pb == progress.getMax())
			        					{
			        					}
			        				}
			        			});
			        			try 
			        			{
			        				Thread.sleep(100); 
			        			}
			        			catch(InterruptedException e){
			        				
			        			}
			        		}
			        	}
			        }).start();
					}
				Intent myIntent = new Intent(Splash.this, MainActivity.class);
			    startActivity(myIntent);
				}
			}, SPLASH_DURATION);
		}
		public void onBackPressed(){
			backbtnPress = true;
			super.onBackPressed();
		}
}