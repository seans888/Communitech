package com.communitech;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy;
import android.os.StrictMode.ThreadPolicy.Builder;
import android.util.Log;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionClass {
    static String classs = "com.mysql.jdbc.Driver";


    public ConnectionClass() {
    }

    @SuppressLint({"NewApi"})
    public static Connection CONN() {
        ThreadPolicy policy = (new Builder()).permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection conn = null;
        Object ConnURL = null;

        try {
            Class.forName(classs);
            conn = DriverManager.getConnection("jdbc:mysql://192.168.1.2:3306/communitech", "root", "");
        } catch (SQLException var4) {
            Log.e("ERROR", var4.getMessage());
        } catch (ClassNotFoundException var5) {
            Log.e("ERROR", var5.getMessage());
        } catch (Exception var6) {
            Log.e("ERROR", var6.getMessage());
        }

        return conn;
    }
}
