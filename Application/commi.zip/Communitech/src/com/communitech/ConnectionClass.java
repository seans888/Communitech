package com.communitech;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionClass {
	static String classs = "com.mysql.jdbc.Driver";
	@SuppressLint("NewApi")
	public static Connection CONN() {
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
		Connection conn = null;
		try {
			Class.forName(classs);
			conn = DriverManager.getConnection("jdbc:mysql://192.168.43.194:3306/communitech","root","");
		} catch (SQLException se) {
			Log.e("ERROR", se.getMessage());
		} catch (ClassNotFoundException e) {
			Log.e("ERROR", e.getMessage());
		}
		catch (Exception e) {
			Log.e("ERROR", e.getMessage());
		}
		return conn;
	}	
}