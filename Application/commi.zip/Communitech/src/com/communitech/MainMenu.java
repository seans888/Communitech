package com.communitech;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainMenu extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_menu);
	}
	public void cal(View v){
		Intent myIntent = new Intent(this, SignUp.class);
        startActivity(myIntent);
	}
	
	public void truck(View v){
		Intent myIntent = new Intent(this, LogIn.class);
        startActivity(myIntent);
	}
}
	

