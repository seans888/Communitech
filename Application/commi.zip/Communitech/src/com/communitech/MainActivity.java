package com.communitech;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity

{
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
}
	
	public void sign(View v){
		Intent myIntent = new Intent(this, SignUp.class);
        startActivity(myIntent);
	}
	
	public void login(View v){
		Intent myIntent = new Intent(this, LogIn.class);
        startActivity(myIntent);
	}
}
