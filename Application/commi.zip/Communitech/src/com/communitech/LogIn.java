package com.communitech;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LogIn extends Activity {
	EditText textUsername, textPassword;
	SQLiteOpenHelper dbhelper;
	SQLiteDatabase sdb;
	List<Object> username2 = new CopyOnWriteArrayList<Object>();
	List<Object> password2 = new CopyOnWriteArrayList<Object>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_reg);}
		public void Main(View v){
			Intent myIntent = new Intent(this, MainMenu.class);
	        startActivity(myIntent);
		String dbname = "communitech.sqlite";
		
		textUsername = (EditText) findViewById(R.id.editUsername);
		textPassword = (EditText) findViewById(R.id.editPassword);
		dbhelper = new SQLiteOpenHelper(this,dbname,null,1) {

			@Override
			public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void onCreate(SQLiteDatabase db) {
				// TODO Auto-generated method stub
			}
		};
	}

	
	public void log(View v){
		sdb = dbhelper.getWritableDatabase();
		String sql = "select * from tb_userprofile";
		Cursor a = sdb.rawQuery(sql, null);
		//list.setText("List of Animals");
		
		while(a.moveToNext()){
			username2.add(a.getString(1));
			password2.add(a.getString(2));
		}
		sdb.close();
		if(username2.contains(textUsername.getText().toString()) && password2.contains(textPassword.getText().toString())){
			setContentView(R.layout.main_menu);
			String text = textUsername.getText().toString();
			SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
			SharedPreferences.Editor edit = sp.edit();
			edit.putString("username",text);
			edit.commit();
		}	
		else if(!username2.contains(textUsername.getText().toString()) && !password2.contains(textPassword.getText().toString())) {
			Toast.makeText(this, "Incorrect Username and Password.", 0).show();
		}
	}
	public void login(View v){
		Intent myIntent = new Intent(this, MainMenu.class);
        startActivity(myIntent);
	}
}
	
