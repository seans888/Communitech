package com.communitech;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class SignUp extends Activity implements android.view.View.OnClickListener {

EditText username,password,fname,lname,email;
RadioButton Radio0,Radio1;
Button save;
DatePicker datePicker;
Calendar calendar;
TextView dateView;
Button button;
private int year, month, day;
SQLiteOpenHelper dbhelper;
SQLiteDatabase sdb;
List<Object> usernameCheck = new CopyOnWriteArrayList<Object>();
List<Object> usernameCheckOnline = new CopyOnWriteArrayList<Object>();
static String userProfile = "tb_userprofile";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sign_up);
		username = (EditText) findViewById(R.id.username);
		password = (EditText) findViewById(R.id.password);
		fname = (EditText) findViewById(R.id.firstname);
		lname = (EditText) findViewById(R.id.lastname);
		email = (EditText) findViewById(R.id.emailadd);
		Radio0 = (RadioButton) findViewById(R.id.radio0);
		Radio1 = (RadioButton) findViewById(R.id.radio1);
		dateView = (TextView) findViewById(R.id.textView1);
	    calendar = Calendar.getInstance();
	    year = calendar.get(Calendar.YEAR);
	    month = calendar.get(Calendar.MONTH);
	    day = calendar.get(Calendar.DAY_OF_MONTH);
	    showDate(year, month+1, day);
		save = (Button) findViewById(R.id.submit);
		save.setOnClickListener(this);
		String dbname = "communitech.sqlite";
		dbhelper = new SQLiteOpenHelper(this,dbname,null,1) {

			@Override
			public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
				// TODO Auto-generated method stub
			}

			@Override
			public void onCreate(SQLiteDatabase db) {
				// TODO Auto-generated method stub
//				sql = "Insert into tb_userprofile (user_name, user_password, user_fname, user_lname, user_email, user_gender, user_dob)"
//					+ " values ('UserName', 'Password', 'FirstName', 'LastName', 'Email', 'Gender', 'DateofBirth' )";
//				db.execSQL(sql);
//				sql = "Insert into tb_animal values ('01','Crocodile', 'Reptile', 'Amphibian with a giant head' )";
//				db.execSQL(sql);
//				sql = "Insert into tb_animal values ('03','Tiger', 'Cat', 'A big cat with stripes' )";
//				db.execSQL(sql);
//				sql = "Insert into tb_animal values ('04','Lion', 'Cat', 'A big cat with a huge maine' )";
//				db.execSQL(sql);
//				sql = "Insert into tb_animal values ('05','Owl', 'Bird', 'A bird of prey with huge eyes' )";
//				db.execSQL(sql);
			}
		};
		sdb = dbhelper.getWritableDatabase();
		String sql = "select username from userprofile";
		Cursor a = sdb.rawQuery(sql, null);
		//list.setText("List of Animals");
		
		while(a.moveToNext()){
			usernameCheck.add(a.getString(0));
		}
		sdb.close();
	 }
	
	 @SuppressWarnings("deprecation")
	   public void setdate(View view) {
	      showDialog(999);
	   }

	   @Override
	   protected Dialog onCreateDialog(int id) {
	      // TODO Auto-generated method stub
	      if (id == 999) {
	         return new DatePickerDialog(this, myDateListener, year, month, day);
	      }
	      return null;
	   }

	   private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
	      @Override
	      public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
	         // TODO Auto-generated method stub
	         // arg1 = year
	         // arg2 = month
	         // arg3 = day
	         showDate(arg1, arg2+1, arg3);
	      }
	   };

	   private void showDate(int year, int month, int day) {
	      dateView.setText(new StringBuilder().append(month).append("/")
	      .append(day).append("/").append(year));
	   }

	   public void onClick(View v) {
			try {
				Connection con = ConnectionClass.CONN();
				if (con == null) {
					Toast.makeText(this,"Error in connection with SQL server", 0).show();
				} else {
					try{
						String query = "select USERUSERNAME.* from USERPROFILE";
						Statement stmt = (Statement) con.createStatement();
						ResultSet rs = stmt.executeQuery(query);
						ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
					while(rs.next()) {
						usernameCheckOnline.add(rs.getString(2));
					}
					
					}catch(SQLException s){
						Log.e("",s.getMessage());
					}
				}
			}catch (Exception ex)
			{
				Log.e("",ex.getMessage());
			}
			if(v.getId() == R.id.submit && usernameCheck.contains(username) && usernameCheckOnline.contains(username)){
				Toast.makeText(this, "Username is already used.", 0).show();
			}
			else if(v.getId() == R.id.submit && Radio0.isChecked() && !usernameCheck.contains(username) && !usernameCheckOnline.contains(username)){
				String gender = "Male";
				sdb=dbhelper.getWritableDatabase();
				String sql = "insert into UserProfile (username, userpassword, userfname, userlname, useremailaddress, userdob)"
				+ " values ('"+ username.getText().toString() +"','"+ password.getText().toString() + "','" +fname.getText().toString()+ "','" +lname.getText().toString()+ 
				"','" +email.getText().toString() + "','" +dateView.getText().toString()+"')";
				sdb.execSQL(sql);
				sdb.close();
				String text = username.getText().toString();
				SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
				SharedPreferences.Editor edit = sp.edit();
				edit.putString("username",text);
				edit.commit();
				try {
					Connection con = ConnectionClass.CONN();
					if (con == null) {
						Toast.makeText(this,"Error in connection with SQL server", 0).show();
					} else {
						try{
						String query = "insert into USERPROFILE (USERUSERNAME, USERPASSWORD, USERFIRSTNAME, USERLASTNAME, USEREMAILADDRESS, USERDATEOFBIRTH)"
								+ " values ('"+ username.getText().toString() +"','"+ password.getText().toString() + "','" +fname.getText().toString()+ "','" +lname.getText().toString()+ 
								"','" +email.getText().toString() + "','" +dateView.getText().toString()+"')";
						PreparedStatement stmt = (PreparedStatement) con.prepareStatement(query);
						stmt.executeUpdate();
						Toast.makeText(this, "Thanks for signing-up! Your account has been added.", 0).show();
						Intent myIntent = new Intent(this, MainMenu.class);
					    startActivity(myIntent);
						}
						catch(SQLException s){
							Log.e("",s.getMessage());
						}
						}
					}
					catch (Exception ex)
					{
						Log.e("",ex.getMessage());
					}
			}
			else if(v.getId() == R.id.submit && Radio1.isChecked() && !usernameCheck.contains(username) && !usernameCheckOnline.contains(username)){
				String gender = "Female";
				sdb =dbhelper.getWritableDatabase();
				String sql = "insert into UserProfile (userUsername, userPassword, userFirstName, userLastName, userEmailAddress, userDateOfBirth)"
						+ " values ('"+ username.getText().toString() +"','"+ password.getText().toString() + "','" +fname.getText().toString()+ "','" +lname.getText().toString()+ 
						"','" +email.getText().toString() + "','" +dateView.getText().toString()+"')";
				sdb.execSQL(sql);
				sdb.close();
				String text = username.getText().toString();
				SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
				SharedPreferences.Editor edit = sp.edit();
				edit.putString("username",text);
				edit.commit();
				try {
					Connection con = ConnectionClass.CONN();
					if (con == null) {
						Toast.makeText(this,"Error in connection with server", 0).show();
					} else {
						try{
						String query = "insert into USERPROFILE (USERUSERNAME, USERPASSWORD, USERFIRSTNAME, USERLASTNAME, USEREMAILADDRESS, USERDATEOFBIRTH)"
								+ " values ('"+ username.getText().toString() +"','"+ password.getText().toString() + "','" +fname.getText().toString()+ "','" +lname.getText().toString()+ 
								"','" +email.getText().toString() + "','" +dateView.getText().toString()+"')";
						PreparedStatement stmt = (PreparedStatement) con.prepareStatement(query);
						stmt.executeUpdate();
						Toast.makeText(this, "Thanks for signing-up! Your account has been added.", 0).show();
						Intent myIntent = new Intent(this, MainMenu.class);
					    startActivity(myIntent); 
						}
						catch(SQLException s){
							Log.e("",s.getMessage());
						}
						}
					}
					catch (Exception ex)
					{
						Log.e("",ex.getMessage());
					}
			}
		}

	public void back1(View v){
		Intent myIntent = new Intent(this, LogIn.class);
        startActivity(myIntent);
	}
}
