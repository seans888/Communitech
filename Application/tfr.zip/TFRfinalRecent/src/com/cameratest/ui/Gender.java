package com.cameratest.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Gender extends Activity {
static boolean mgender = false;
static boolean fgender = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gender);
	}
	public boolean male(View v){
		Intent intent = new Intent(this, MainActivity.class);
		startActivity(intent);
		fgender = false;
		return mgender = true;
	}
	public boolean female(View v){
		Intent intent = new Intent(this, MainActivity.class);
		startActivity(intent);
		mgender = false;
		return fgender = true;
	}
}
