package com.cameratest.ui;

import java.sql.ResultSet;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSetMetaData;
import com.mysql.jdbc.Statement;

public class Loginpage extends Activity {
	EditText username, password;
	String uname, upass;
	SQLiteOpenHelper dbhelper;
	SQLiteDatabase sdb;
	ProgressBar pbbar;
	List<Object> userid = new CopyOnWriteArrayList<Object>();
	List<Object> username2 = new CopyOnWriteArrayList<Object>();
	List<Object> password2 = new CopyOnWriteArrayList<Object>();
	List<Object> uname1 = new CopyOnWriteArrayList<Object>();
	List<Object> upass1 = new CopyOnWriteArrayList<Object>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_loginpage);
		String dbname = "tfr.sqlite";
		
		username = (EditText) findViewById(R.id.username1);
		password = (EditText) findViewById(R.id.password1);
		dbhelper = new SQLiteOpenHelper(this,dbname,null,1) {

			@Override
			public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void onCreate(SQLiteDatabase db) {
				// TODO Auto-generated method stub
			}
		};
	}
	public void sign(View v){
		Intent myIntent = new Intent(this, Signup.class);
        startActivity(myIntent);
	}
	
	public void ok(View v){
		Intent myIntent = new Intent(this, Main.class);
        startActivity(myIntent);
	}
	
	public void log(View v){
		uname = username.toString();
		upass = password.toString();
		sdb = dbhelper.getWritableDatabase();
		String sql = "select * from UserProfile";
		Cursor a = sdb.rawQuery(sql, null);
		//list.setText("List of Animals");
		
		while(a.moveToNext()){
			userid.add(a.getString(0));
			username2.add(a.getString(1));
			password2.add(a.getString(2));
		}
		sdb.close();
		if(username2.contains(username.getText().toString()) && password2.contains(password.getText().toString())){
			String text = username.getText().toString();
			SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
			SharedPreferences.Editor edit = sp.edit();
			edit.putString("username",text);
			edit.commit();
			Toast.makeText(Loginpage.this,"Login Successful", 0).show();
           	Intent myIntent = new Intent(this, Main.class);
            startActivity(myIntent);
//            try {
//                Connection con = (Connection) ConnectionClass.CONN();
//                if (con == null) {
//                	Toast.makeText(Loginpage.this,"Error in connection with SQL server", 0).show();
//                } else {
//                    String query = "SELECT * FROM USERPROFILE where USERUSERNAME = '" + username + "' and USERPASSWORD = '" + password + "'";
//                    PreparedStatement stmt = (PreparedStatement) con.prepareStatement(query);
//                    ResultSet rs = stmt.executeQuery();
//                    ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
//                    while(rs.next())
//                    {
//                    	uname1.add(rs.getString(1)); 
//                    	upass1.add(rs.getString(2));
//                    }
//                    if(uname1.contains(username) && upass1.contains(password)){
//                     	Toast.makeText(Loginpage.this,"Login Successful", 0).show();
//	                   	Intent myIntent = new Intent(this, Main.class);
//	                    startActivity(myIntent);
//                    }
//                    else
//                    {
//                       	Toast.makeText(Loginpage.this,"Invalid Credentials", 0).show();
//                    }
//                }
//            }
//            catch (Exception ex)
//            {
//            	Toast.makeText(Loginpage.this,"Exception: "+ex, 0).show();
//            }
		}
		else if(!username2.contains(username.getText().toString()) && !password2.contains(password.getText().toString())) {
			Toast.makeText(this, "Incorrect Username and Password.", 0).show();
		}
		else if(!username2.contains(username.getText().toString()) && password2.contains(password.getText().toString())) {
			Toast.makeText(this, "Incorrect Username or Password.", 0).show();
		}
		else if(username2.contains(username.getText().toString()) && !password2.contains(password.getText().toString())) {
			Toast.makeText(this, "Incorrect Username or Password.", 0).show();
		}
	}
}
	
