package com.cameratest.ui;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.camera.util.TouchImageView;
import com.camera.util.TouchImageView.OnTouchImageViewListener;

public class FittingRoom extends Activity {
	
	boolean mgender = Gender.mgender;
	boolean fgender = Gender.fgender;
	static String image = "";
    SQLiteOpenHelper dbhelper;
    SQLiteDatabase sdb;
    TouchImageView view;
    RelativeLayout rl;
    Bitmap myBitmap;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_fitting_room);
		try{
//			if(mgender == true && fgender == false){
//				ImageView imageView1 = (ImageView) findViewById(R.id.imageView1);
//				imageView1.setVisibility(View.VISIBLE);
//			}
//			else if(fgender == true && mgender == false){
//				ImageView imageView2 = (ImageView) findViewById(R.id.imageView2);
//				imageView2.setVisibility(View.VISIBLE);
//			}
		 	Intent intent = getIntent();
		 	SharedPreferences sp = getSharedPreferences("setting", MODE_PRIVATE);
			String path = sp.getString("ipath", "No data...");
		    File imgfile = new File(path);
			Bitmap myBitmap = BitmapFactory.decodeFile(imgfile.getAbsolutePath());
			ImageView imageView = (ImageView) findViewById(R.id.imageView01);
			final TouchImageView view = (TouchImageView) findViewById(R.id.imview);
			Matrix matrix = new Matrix();
			matrix.setRotate(90);
			Bitmap bmpRotate = Bitmap.createBitmap(myBitmap, 0, 0, myBitmap.getWidth(), myBitmap.getHeight(), matrix, true);
			imageView.setImageBitmap(bmpRotate);
//			ByteArrayOutputStream blob = new ByteArrayOutputStream();
//			myBitmap.compress(Bitmap.CompressFormat. JPEG, 100, blob);
//			byte[] byteArray = blob.toByteArray();
//			sdb = dbhelper.getWritableDatabase();
//			String sql = "Insert into tb_image(img_name, image) values ('Selfie','" + byteArray + "' ) ";
//					Toast.makeText(this, "Selfie saved", 0).show();
//			sdb.execSQL(sql);
//			sdb.close();
			view.setOnTouchImageViewListener(new OnTouchImageViewListener() {
				
				public void onMove() {
					// TODO Auto-generated method stub
					PointF point = view.getScrollPosition();
					RectF rect = view.getZoomedRect();
					float currentZoom = view.getCurrentZoom();
					boolean isZoomed = view.isZoomed();
				}
			});
		} catch (NullPointerException e) {
			Toast.makeText(this, "No Selfie captured. You may view the shirts of your Liking", 0).show();
		} catch (RuntimeException e){
			Toast.makeText(this, "RuntimeException", 0).show();
		}
		
		
	}
	
	public void recall(){
		try{
//			if(mgender == true && fgender == false){
//				ImageView imageView1 = (ImageView) findViewById(R.id.imageView1);
//				imageView1.setVisibility(View.VISIBLE);
//			}
//			else if(fgender == true && mgender == false){
//				ImageView imageView2 = (ImageView) findViewById(R.id.imageView2);
//				imageView2.setVisibility(View.VISIBLE);
//			}
		 	Intent intent = getIntent();
		 	SharedPreferences sp = getSharedPreferences("setting", MODE_PRIVATE);
			String path = sp.getString("ipath", "No data...");
		    File imgfile = new File(path);
			Bitmap myBitmap = BitmapFactory.decodeFile(imgfile.getAbsolutePath());
			ImageView imageView = (ImageView) findViewById(R.id.imageView01);
			Matrix matrix = new Matrix();
			matrix.setRotate(90);
			Bitmap bmpRotate = Bitmap.createBitmap(myBitmap, 0, 0, myBitmap.getWidth(), myBitmap.getHeight(), matrix, true);
			imageView.setImageBitmap(bmpRotate);
//			ByteArrayOutputStream blob = new ByteArrayOutputStream();
//			myBitmap.compress(Bitmap.CompressFormat. JPEG, 100, blob);
//			byte[] byteArray = blob.toByteArray();
//			sdb = dbhelper.getWritableDatabase();
//			String sql = "Insert into tb_image(img_name, image) values ('Selfie','" + byteArray + "' ) ";
//					Toast.makeText(this, "Selfie saved", 0).show();
//			sdb.execSQL(sql);
//			sdb.close();
		} catch (NullPointerException e) {
			Toast.makeText(this, "No Selfie captured. You may view the shirts of your Liking", 0).show();
		} catch (RuntimeException e){
			Toast.makeText(this, "RuntimeException", 0).show();
		}
	}
	Bitmap clothes1;
	
	public void goback(View v){
		setContentView(R.layout.activity_fitting_room);
		recall();
		try{
			TouchImageView clothes = (TouchImageView) findViewById(R.id.imview);
			clothes.setImageBitmap(clothes1);
			clothes.getLayoutParams().height = 2000;
			clothes.getLayoutParams().width = 2000;
			
			clothes.requestLayout();
			clothes.setVisibility(View.VISIBLE);
			
			//imageView1.setVisibility(View.INVISIBLE);
		}catch (NullPointerException e) {
			Toast.makeText(this, "No Selfie captured. You may view the shirts of your Liking", 0).show();
		} catch (RuntimeException e){
			Toast.makeText(this, "RuntimeException", 0).show();
		}
		catch (Exception e) {
			Toast.makeText(this, ""+e, 0).show();
		}
	}
	
	public void save(View v){
		//take screenshot
		rl = (RelativeLayout)findViewById(R.id.fl1);
        rl.post(new Runnable() {
            public void run() {
 
                //take screenshot
                myBitmap = captureScreen(rl);
 
                try {
                    if(myBitmap!=null){
                        //save image to SD card
                        saveImage(myBitmap);
                    }
                    Toast.makeText(getApplicationContext(), "Picture saved..!", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(),Main.class);
                    startActivity(intent);
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
 
            }
        });
	}
	public static Bitmap captureScreen(View v) {
		 
        Bitmap screenshot = null;
        try {
 
            if(v!=null) {
 
                screenshot = Bitmap.createBitmap(v.getMeasuredWidth(),v.getMeasuredHeight(), Config.ARGB_8888);
                Canvas canvas = new Canvas(screenshot);
                v.draw(canvas);
            }
 
        }catch (Exception e){
            Log.d("ScreenShotActivity", "Failed to capture screenshot because:" + e.getMessage());
        }
 
        return screenshot;
    }
    public static void saveImage(Bitmap bitmap) throws IOException{
 
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 40, bytes);
        String root = Environment.getExternalStorageDirectory().toString();
		File myDir = new File(root + "/tfrClothes");    
		myDir.mkdirs();
		Random generator = new Random();
		int n = 10000;
		n = generator.nextInt(n);
		String fname = "Image-"+ n +".jpg";
		File file = new File (myDir, fname);
		if (file.exists ()) file.delete (); 
        file.createNewFile();
        FileOutputStream fo = new FileOutputStream(file);
        fo.write(bytes.toByteArray());
        fo.close();
    }
	public void clothes(View v){
//		sdb = dbhelper.getWritableDatabase();
//		String sql  = "Select * from tb_image";
//		sdb.execSQL(Squall);
//		Cursor c = sdb.rawQuery(sql, null);
//		byte[] byteArray = c.getBlob(2);
//		Bitmap bm = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
//		sdb.close();
		
		setContentView(R.layout.activity_clothes_list);
		 ImageView im1 =(ImageView)findViewById(R.id.image1);
   		 ImageView im2 =(ImageView)findViewById(R.id.image2);
   		 ImageView im3 =(ImageView)findViewById(R.id.image3);
   		 ImageView im4 =(ImageView)findViewById(R.id.image4);
   		 ImageView im5 =(ImageView)findViewById(R.id.image5);
   		 ImageView im6 =(ImageView)findViewById(R.id.image6);
   		 ImageView im7 =(ImageView)findViewById(R.id.image7);
   		
    	im1.setOnClickListener(new Button.OnClickListener(){
	        @Override
		    public void onClick(View v) {
	        	clothes1 = BitmapFactory.decodeResource(getResources(), R.drawable.shirt1);
	        	goback(v);
	        }
    	});
    	im2.setOnClickListener(new Button.OnClickListener(){
	        @Override
		    public void onClick(View v) {
	        	clothes1 = BitmapFactory.decodeResource(getResources(), R.drawable.shirt2);
	        	goback(v);
	        }
    	});
    	im3.setOnClickListener(new Button.OnClickListener(){
	        @Override
		    public void onClick(View v) {
	        	clothes1 = BitmapFactory.decodeResource(getResources(), R.drawable.shirt3);
	        	goback(v);
	        }
    	});
    	im4.setOnClickListener(new Button.OnClickListener(){
	        @Override
		    public void onClick(View v) {
	        	clothes1 = BitmapFactory.decodeResource(getResources(), R.drawable.shirt4);
	        	goback(v);
	        }
    	});
    	im5.setOnClickListener(new Button.OnClickListener(){
	        @Override
		    public void onClick(View v) {
	        	clothes1 = BitmapFactory.decodeResource(getResources(), R.drawable.shirt5);
	        	goback(v);
	        }
    	});
    	im6.setOnClickListener(new Button.OnClickListener(){
	        @Override
		    public void onClick(View v) {
	        	clothes1 = BitmapFactory.decodeResource(getResources(), R.drawable.shirt6);
	        	goback(v);
	        }
    	});
    	im7.setOnClickListener(new Button.OnClickListener(){
	        @Override
		    public void onClick(View v) {
	        	clothes1 = BitmapFactory.decodeResource(getResources(), R.drawable.shirt7);
	        	goback(v);
	        }
    	});

	}
	public void Back(View v){
		Intent intent = new Intent(this, MainActivity.class);
		startActivity(intent);
	}
//	public void BackCl(View v){
//		setContentView(R.layout.activity_fitting_room);
//		recall();
//		if(clothes1.sameAs(clothes1)){
//			ImageView clothes = (ImageView) findViewById(R.id.imageView3);
//			clothes.setImageBitmap(clothes1);
//			clothes.getLayoutParams().height = 540;
//			clothes.getLayoutParams().width = 580;
//			clothes.requestLayout();
//			clothes.setVisibility(View.VISIBLE);
//		}
//	}
//	int hght = 480;
//	int wdth = 540;
//	public void Sm (View v){
//		ImageView clothes = (ImageView) findViewById(R.id.imageView3);//setting layout params
//		if(hght > 370 && wdth > 440){
//		hght -=4;
//		wdth -=4;
//		}
//		clothes.getLayoutParams().height = hght;
//		clothes.getLayoutParams().width = wdth;
//		clothes.requestLayout();
//	}
//	public void Md(View v){
//		ImageView clothes = (ImageView) findViewById(R.id.imageView3);
//
//		clothes.getLayoutParams().height = 480;
//		clothes.getLayoutParams().width = 540;
//
//		clothes.requestLayout();
//	}
//	public void Lg(View v){
//		ImageView clothes = (ImageView) findViewById(R.id.imageView3);
//		if(hght < 550 && wdth < 610){
//			hght +=4;
//			wdth +=4;
//		}
//		clothes.getLayoutParams().height = hght;
//		clothes.getLayoutParams().width = wdth;
//		clothes.requestLayout();
//	}
}
