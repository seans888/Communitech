package com.cameratest.ui;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class SizeEdit extends View {
	static int sop = 1;
	int shoulderWidthabs; int bodyLengthabs;
	public SizeEdit(Context context, AttributeSet attrs) {
		super(context, attrs);
		
	}
	ArrayList<Rect> lines= new ArrayList<Rect>();
	int x1, y1;
	int x2, y2;
	int a1, a2, b1, b2;
	boolean drawing=false;
	@Override
	protected void onDraw(Canvas canvas) 
	{
		// TODO Auto-generated method stub
		super.onDraw(canvas);


		
		Paint p= new Paint();
		p.setTextSize(20);
		p.setStrokeWidth(5);
		p.setColor(Color.RED);
		canvas.drawText("Shoulder Width: " + shoulderWidthabs, 10, 400, p);
		canvas.drawText("Body Length: " + bodyLengthabs, 10, 430, p);
		if (drawing){
			canvas.drawLine(x1, y1, x2, y2, p);
			canvas.drawLine(a1, b1, a2, b2, p);
		}
		else
			for (int i=0; i<lines.size(); i++)
			{
				Rect currline= lines.get(i);
				canvas.drawLine(currline.left, currline.top, currline.right, currline.bottom, p);
			}
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) 
	{
		boolean result=false;
		if(sop == 2){
			
			switch (event.getAction()) 
			{
			case MotionEvent.ACTION_DOWN:
				a1=a2= (int)event.getX();
				b1=b2= (int)event.getY();
				drawing=true;
				result=true;
				break;

			case MotionEvent.ACTION_MOVE:
				//x2= (int)event.getX();
				b2= (int)event.getY();
				drawing=true;
				result=true;

				break;

			case MotionEvent.ACTION_UP:
				//x2= (int)event.getX();
				b2= (int)event.getY();
				lines.add(new Rect(a1, b1, a2, b2));
				drawing=true;
				result=true;
				break;
			}
		}
		if(sop == 1){
			switch (event.getAction()) 
			{
			case MotionEvent.ACTION_DOWN:
				x1=x2= (int)event.getX();
				y1=y2= (int)event.getY();
				drawing=true;
				result=true;
				break;

			case MotionEvent.ACTION_MOVE:
				x2= (int)event.getX();
				//y2= (int)event.getY();
				drawing=true;
				result=true;

				break;

			case MotionEvent.ACTION_UP:
				x2= (int)event.getX();
				//y2= (int)event.getY();
				lines.add(new Rect(x1, y1, x2, y2));
				drawing=true;
				result=true;
				break;
			}
		}
		if (result)
		 shoulderWidthabs = x2-x1;
		 bodyLengthabs = b2-b1;
		 invalidate();

			if(shoulderWidthabs < 0){
				shoulderWidthabs = shoulderWidthabs * -1;
			}
			if(bodyLengthabs < 0){
				bodyLengthabs = bodyLengthabs * -1;
			}
			
		return result;
	}
}
