package com.cameratest.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class StartScre extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.startup);
	}
	public void start(View v){
		Intent myIntent = new Intent(this, Loginpage.class);
        startActivity(myIntent);
	}
	
}



