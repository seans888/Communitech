package com.cameratest.ui;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

public class Profilepage extends Activity {

	TextView username,fname,lname,email,gender,dob,prime;
	SQLiteOpenHelper dbhelper;
	Button syncbutton;
	SQLiteDatabase sdb;
	ProgressDialog prgDialog;
	HashMap<String, String> queryValues;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profilepage);
		String dbname = "tfr.sqlite";
		username = (TextView) findViewById(R.id.tvusername);
		fname = (TextView) findViewById(R.id.tvfirstname);
		lname = (TextView) findViewById(R.id.tvlastname);
		email = (TextView) findViewById(R.id.tvemailadd);
		dob = (TextView) findViewById(R.id.tvdob);
		//prime = (TextView) findViewById(R.id.textView1);
		SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
		String st = sp.getString("username", username.getText().toString());
		dbhelper = new SQLiteOpenHelper(this,dbname,null,1) {

			@Override
			public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
				// TODO Auto-generated method stub
			}

			@Override
			public void onCreate(SQLiteDatabase db) {
				// TODO Auto-generated method stub
			}
		};

		sdb = dbhelper.getWritableDatabase();
		String sql = "select * from UserProfile where userUsername = '"+st+"'";
		Cursor a = sdb.rawQuery(sql, null);
		//list.setText("List of Animals");
		try{
			while(a.moveToNext()){
				username.append(a.getString(1));
				fname.append(a.getString(3));
				lname.append(a.getString(4));
				email.append(a.getString(5));
				dob.append(a.getString(6).toString());
		
				//prime.append(a.getString(0));
			}
		}catch(Exception e){
			e.printStackTrace();
			Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
			Intent myIntent = new Intent(this, Main.class);
	        startActivity(myIntent);
		}

//		ArrayList<HashMap<String, String>> usersList;
//		usersList = new ArrayList<HashMap<String, String>>();
//		Cursor cursor = sdb.rawQuery(sql, null);
//		if (cursor.moveToFirst()) {
//			do {
//				HashMap<String, String> map = new HashMap<String, String>();
//				map.put("userID", cursor.getString(0));
//				map.put("userUsername", cursor.getString(1));
//				map.put("userFirstName", cursor.getString(3));
//				map.put("userLastName", cursor.getString(4));
//				map.put("userEmailAddress", cursor.getString(5));
//				map.put("userDateOfBirth", cursor.getString(6));
//				//	        	map.put("userSizeID", cursor.getString(9));
//				usersList.add(map);
//			} while (cursor.moveToNext());
//		}
		sdb.close();
		prgDialog = new ProgressDialog(this);
		prgDialog.setMessage("Transferring Data from TFR Website. Please Wait");
		prgDialog.setCancelable(false);
	}
	
	
//	public void syncbutton(View v){
//		try{
//			syncSQLiteMySQLDB();
//		}
//		catch(Exception e){
//			e.printStackTrace();
//			Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
//			Intent myIntent = new Intent(this, Profilepage.class);
//	        startActivity(myIntent);
//		}
//	}
//	public void syncSQLiteMySQLDB() {
//		AsyncHttpClient client = new AsyncHttpClient();
//		RequestParams params = new RequestParams();
//		prgDialog.show();
//		client.post("http://10.0.2.2/getusers.php", params, new AsyncHttpResponseHandler() {
//			@Override
//			public void onSuccess(String response) {
//				prgDialog.hide();
//				updateSQLite(response);
//			}
//			@Override
//			public void onFailure(int statusCode, Throwable error, String content) {
//				prgDialog.hide();
//				if (statusCode == 404) {
//					Toast.makeText(getApplicationContext(), "Requested resource not found", Toast.LENGTH_LONG).show();
//				} else if (statusCode == 500) {
//					Toast.makeText(getApplicationContext(), "Something went wrong at server end", Toast.LENGTH_LONG).show();
//				} else {
//					Toast.makeText(getApplicationContext(), "Unexpected Error occcured! [Most common Error: Device might not be connected to Internet]",
//							Toast.LENGTH_LONG).show();
//				}
//			}
//		});
//	}
//
//	public void updateSQLite(String response){
//		ArrayList<HashMap<String, String>> usersynclist;
//		usersynclist = new ArrayList<HashMap<String, String>>();
//		Gson gson = new GsonBuilder().create();
//		try {
//			JSONArray arr = new JSONArray(response);
//			System.out.println(arr.length());
//			if(arr.length() != 0){
//				for (int i = 0; i < arr.length(); i++) {
//					JSONObject obj = (JSONObject) arr.get(i);
//					System.out.println(obj.get("userID"));
//					System.out.println(obj.get("userUsername"));
//					System.out.println(obj.get("userFirstName"));
//					System.out.println(obj.get("userLastName"));
//					System.out.println(obj.get("userEmailAddress"));
//					System.out.println(obj.get("userDateOfBirth"));
//					//					obj.get("userPhotoModel");
//					//					obj.get("userWishlist");
//					//					obj.get("userSizeID");
//					queryValues = new HashMap<String, String>();
//					queryValues.put("userID", obj.get("userID").toString());
//					queryValues.put("userUsername", obj.get("userUsername").toString());
//					queryValues.put("userFirstName", obj.get("userFirstName").toString());
//					queryValues.put("userLastName", obj.get("userLastName").toString());
//					queryValues.put("userEmailAddress", obj.get("userEmailAddress").toString());
//					queryValues.put("userDateOfBirth", obj.get("userDateOfBirth").toString());
//					//					queryValues.put("userPhotoModel", obj.get("userPhotoModel").toString());
//					//					queryValues.put("userWishlist", obj.get("userWishlist").toString());
//					//					queryValues.put("userSizeID", obj.get("userSizeID").toString());
//					//					queryValues.put("userSize", obj.get("userSize").toString());
//					//					queryValues.put("userChestWidth", obj.get("userChestWidth").toString());
//					//					queryValues.put("userShirtLength", obj.get("userShirtLength").toString());
//					//					queryValues.put("userGender", obj.get("userGender").toString());
//					//					queryValues.put("userWaist", obj.get("userWaist").toString());
//					//					queryValues.put("userHips", obj.get("userHips").toString());
//
//					insertUser(queryValues);
//
//					HashMap<String, String> map = new HashMap<String, String>();
//					map.put("USERID", obj.get("userID").toString());
//					map.put("USERUSERNAME", obj.get("userUsername").toString());
//					map.put("USERFIRSTNAME", obj.get("userFirstName").toString());
//					map.put("USERLASTNAME", obj.get("userLastName").toString());
//					map.put("USEREMAILADDRESS", obj.get("userEmailAddress").toString());
//					map.put("USERDATEOFBIRTH", obj.get("userDateOfBirth").toString());
//					//					map.put("USERSIZE", obj.get("userSize").toString());
//					//					map.put("USERCHESTWIDTH", obj.get("userChestWidth").toString());
//					//					map.put("USERSHIRTLENGTH", obj.get("userShirtLength").toString());
//					//					map.put("USERGENDER", obj.get("userGender").toString());
//					//					map.put("USERWAIST", obj.get("userWaist").toString());
//					//					map.put("USERHIPS", obj.get("userHips").toString());
//					map.put("USERSTATUS", "1");
//					usersynclist.add(map);
//				}
//				updateMySQLSyncSts(gson.toJson(usersynclist));
//				reloadActivity();
//			}
//		} catch (JSONException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	public void insertUser(HashMap<String, String> queryValues) {
//		sdb = dbhelper.getWritableDatabase();
//		ContentValues values = new ContentValues();
//		ContentValues values1 = new ContentValues();
//		values.put("userID", queryValues.get("userID"));
//		values.put("userUsername", queryValues.get("userUsername"));
//		values.put("userFirstName", queryValues.get("userFirstName"));
//		values.put("userLastName", queryValues.get("userLastName"));
//		values.put("userEmailAddress", queryValues.get("userEmailAddress"));
//		values.put("userDateOfBirth", queryValues.get("userDateOfBirth"));
//		//		values.put("userSizeID", queryValues.get("userSizeID"));
//		//		values.put("userPhotoModel", queryValues.get("userPhotoModel"));
//		//		values.put("userWishlist", queryValues.get("userWishlist"));
//		//		values1.put("userSizeID", queryValues.get("userSizeID"));
//		//		values1.put("userSize", queryValues.get("userSize"));
//		//		values1.put("userChestWidth", queryValues.get("userChestWidth"));
//		//		values1.put("userShirtLength", queryValues.get("userShirtLength"));
//		//		values1.put("userGender", queryValues.get("userGender"));
//		//		values1.put("userWaist", queryValues.get("userWaist"));
//		//		values1.put("userHips", queryValues.get("userHips"));
//		sdb.insert("UserProfile", null, values);
//		//		sdb.insert("UserSize", null, values1);
//		sdb.close();
//	}
//
//	public void updateMySQLSyncSts(String json) {
//		System.out.println(json);
//		AsyncHttpClient client = new AsyncHttpClient();
//		RequestParams params = new RequestParams();
//		params.put("USERSTATUS", json);
//		// Make Http call to updatesyncsts.php with JSON parameter which has Sync statuses of Users
//		client.post("http://10.0.2.2/updatesyncsts.php", params, new AsyncHttpResponseHandler() {
//			@Override
//			public void onSuccess(String response) {
//				Toast.makeText(getApplicationContext(),	"MySQL DB has been informed about Sync activity", Toast.LENGTH_LONG).show();
//			}
//
//			@Override
//			public void onFailure(int statusCode, Throwable error, String content) {
//				Toast.makeText(getApplicationContext(), "Error Occured", Toast.LENGTH_LONG).show();
//			}
//		});
//	}
//
//	public void reloadActivity() {
//		Intent objIntent = new Intent(getApplicationContext(), Profilepage.class);
//		startActivity(objIntent);
//	}
	public void back(View v){
		Intent intent = new Intent(this, Main.class);
		startActivity(intent);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.profilepage, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
