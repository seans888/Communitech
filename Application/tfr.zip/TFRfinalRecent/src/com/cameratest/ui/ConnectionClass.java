package com.cameratest.ui;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionClass {
	static String classs = "com.mysql.jdbc.Driver";
	@SuppressLint("NewApi")
	public static Connection CONN() {
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
		.permitAll().build();
		StrictMode.setThreadPolicy(policy);
		Connection conn = null;
		String ConnURL = null;
		try {
			Class.forName(classs);
			//ConnURL = "jdbc:mysql://10.0.2.2:3306/"+ db;
			conn = DriverManager.getConnection("jdbc:mysql://192.168.16.2:3306/tfr","root","");
			//conn = DriverManager.getConnection("jdbc:mysql://10.0.2.2:3306/tfr","root","");
		} catch (SQLException se) {
			Log.e("ERROR", se.getMessage());
		} catch (ClassNotFoundException e) {
			Log.e("ERROR", e.getMessage());
		}
		catch (Exception e) {
			Log.e("ERROR", e.getMessage());
		}
		return conn;
	}	
}