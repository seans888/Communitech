package com.cameratest.ui;


import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ProgressBar;
import android.widget.TextView;

public class Splash extends Activity {
		private boolean backbtnPress;
		private static final int SPLASH_DURATION = 6000;
		private Handler myHandler;
		SQLiteOpenHelper dbhelper;
		SQLiteDatabase sdb;
		TextView text1;
	    Animation animFadein;
	    ProgressBar progress; 
		int pb = 0; 
		Handler h = new Handler();
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			
			// TODO Auto-generated method stub
			super.onCreate(savedInstanceState);
			setContentView(R.layout.splash);
			String dbname = "tfr.sqlite";
			dbhelper = new SQLiteOpenHelper(this,dbname,null,1) {

				@Override
				public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
					// TODO Auto-generated method stub
				}

				@Override
				public void onCreate(SQLiteDatabase db) {
					// TODO Auto-generated method stub

					String query = "create table UserProfile(userID integer primary key autoincrement, userUsername text, userPassword text, userFirstName text, userLastName text, userEmailAddress text, userDateofBirth text, userPhotoModel blob null, userWishlist int null)";
					String query1 = "create table Tshirt(itemCode text primary key, ShirtName text, ShirtImage blob, ShirtGender text, BrandCode text, ShirtBrand text, ShirtColor text, ShirtMaterial text, ShirtWebsite text)";
					String query2 = "create table TshasUser(itemCode text, userID integer, userPhotoModel blob)";
					String query3 = "create table AdminProfile(adminID integer primary key autoincrement, adminUsername text, adminPassword text, adminFirstname text, adminLastname text, adminEmailAddress text, adminGender text, adminDateOfBirth text, adminPrivilege text, adminBrand text)";
					db.execSQL(query);
					db.execSQL(query1);
					db.execSQL(query2);
					db.execSQL(query3);
				}
			};

			sdb = dbhelper.getWritableDatabase();
//			String sql = "select * from tb_animal";
//			Cursor a = sdb.rawQuery(sql, null);
//			list.setText("List of Animals");
//			list.append("\r\n");
//			while(a.moveToNext()){
//				list.append( a.getString(0) + " | " + a.getString(1) + " | "+ a.getString(2) + " | "+ a.getString(3));
//				list.append("\r\n");
//			}
			sdb.close();
			myHandler = new Handler();
			myHandler.postDelayed(new Runnable(){

				@Override
				public void run() {
					finish();	
				if(!backbtnPress){
					progress = (ProgressBar)findViewById(R.id.progressBar1);
			        new Thread(new Runnable()
			        {
			        	@Override
			        	public void run()
			        	{
			        		for(int i=0; i<100; i++)
			        		{
			        			pb+=1; 
			        			h.post(new Runnable()
			        			{
			        				public void run()
			        				{
			        					progress.setProgress(pb); 
			        					if(pb == progress.getMax())
			        					{
			        						
			        					}
			        				}
			        			});
			        			try 
			        			{
			        				Thread.sleep(100); 
			        			}
			        			catch(InterruptedException e){
			        				
			        			}
			        		}
			        	}
			        }).start();
				}
				Intent myIntent = new Intent(Splash.this, StartScre.class);
			    startActivity(myIntent);
				}
			}, SPLASH_DURATION);
		}
		public void onBackPressed(){
			backbtnPress = true;
			super.onBackPressed();
		}
}