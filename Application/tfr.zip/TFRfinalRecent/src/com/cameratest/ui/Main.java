package com.cameratest.ui;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class Main extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activitymain);
	}
	public void camera(View v){
		Intent myIntent = new Intent(this, Gender.class);
        startActivity(myIntent);
	}
	public void guide(View v){
		setContentView(R.layout.guide);
	}
	public void album(View v){
//		File mediaStorageDir = new File(Environment.getExternalStorageDirectory(), "tfrClothes");
//		File imgfile = new File(mediaStorageDir.getPath() + File.separator);
//		Bitmap myBitmap = BitmapFactory.decodeFile(imgfile.getAbsolutePath());
//		ImageView imageView = (ImageView) findViewById(R.id.imageView1);
//		Matrix matrix = new Matrix();
//		matrix.setRotate(90);
//		Bitmap bmpRotate = Bitmap.createBitmap(myBitmap, 0, 0, myBitmap.getWidth(), myBitmap.getHeight(), matrix, true);
//		imageView.setImageBitmap(bmpRotate);
//		setContentView(R.layout.album);
		Intent myIntent = new Intent(this, ShirtList.class);
        startActivity(myIntent);
	}
	public void Back(View v){
		Intent intent = new Intent(this,Main.class);
		startActivity(intent);
	}
	public void settings(View v){
		setContentView(R.layout.setting);
	}
	public void about(View v){
		setContentView(R.layout.about);
	}
	public void profile(View v){
		Intent myIntent = new Intent(this, Profilepage.class);
        startActivity(myIntent);
	}
	public void logout(View v){
		Intent myIntent = new Intent(this, Loginpage.class);
        startActivity(myIntent);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
