package com.cameratest.ui;

public class UserProf {
	 int _id;
 	 String _name;
 	 String _password;
 	 String _first_name;
 	 String _last_name;
 	 String _email;
 	 String _gender;
 	 String _dob;
 	 String _photo_model;
 	 String _size;
 	 String _shoulder_rightK;
 	 String _shoulder_leftK;
 	 String _left_bottomK;
 	 String _right_bottomK;
	     
	    // Empty constructor
	    public UserProf(){
	         
	    }
	    // constructor
	    public UserProf(int userID, String userName, String userPassword, String userFirstN,
	    		String userLastN, String userEmail, String userGender, String userDateOfBirth,
	    		String userPhotoModel, String userSize, String userShoulderRightK, 
	    		String userShoulderLeftK, String userLeftBottomK, String userRightBottomK){
	    	
		        this._id = userID;
		        this._name = userName;
		        this._password = userPassword;
		        this._first_name = userFirstN;
		        this._last_name = userLastN;
		        this._email = userEmail;
		        this._gender = userGender;
		        this._dob = userDateOfBirth;
		        this._photo_model = userPhotoModel;
		        this._size = userSize;
		       
	    }
	     
	    // getting ID
	    public int getID(){
	        return this._id;
	    }
	     
	    // setting id
	    public void setID(int userID){
	        this._id = userID;
	    }
	     
	    // getting name
	    public String getName(){
	        return this._name;
	    }
	     
	    // setting name
	    public void setName(String userName){
	        this._name = userName;
	    }
	     
	    // getting phone number
	    public String getPassword(){
	        return this._password;
	    }
	     
	    // setting phone number
	    public void setPassword(String userPassword){
	        this._password = userPassword;
	    }
	    
	 // getting phone number
	    public String getFirstN(){
	        return this._first_name;
	    }
	     
	    // setting phone number
	    public void setFirstN(String userFirstN){
	        this._first_name = userFirstN;
	    }
	    
	 // getting phone number
	    public String getLastN(){
	        return this._last_name;
	    }
	     
	    // setting phone number
	    public void setLastN(String userLastN){
	        this._last_name = userLastN;
	    }
	    
	 // getting phone number
	    public String getEmail(){
	        return this._email;
	    }
	     
	    // setting phone number
	    public void setEmail(String userEmail){
	        this._email = userEmail;
	    }
	    
	 // getting phone number
	    public String getGender(){
	        return this._gender;
	    }
	     
	    // setting phone number
	    public void setGender(String userGender){
	        this._gender = userGender;
	    }
	    
	 // getting phone number
	    public String getDOB(){
	        return this._dob;
	    }
	     
	    // setting phone number
	    public void setDOB(String userDateOfBirth){
	        this._dob = userDateOfBirth;
	    }
	    
	 // getting phone number
	    public String getPhotoM(){
	        return this._photo_model;
	    }
	     
	    // setting phone number
	    public void setPhotoM(String userPhotoModel){
	        this._photo_model = userPhotoModel;
	    }
	    
	 // getting phone number
	    public String getSize(){
	        return this._size;
	    }
	     
	    // setting phone number
	    public void setSize(String userSize){
	        this._size = userSize;
	    }
	    
	 
}
