package com.cameratest.ui;

import java.io.File;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class EditedCanvas extends View {

	Paint p;
	Rect gridsrc, griddest;
	Bitmap grid;
	
	public EditedCanvas (Context context, AttributeSet attrs) {
		super(context, attrs);
		
		p = new Paint();
		grid = BitmapFactory.decodeResource(getResources(), R.drawable.alignment);
		gridsrc = new Rect(0,0,784,1024);
		griddest = new Rect(20,130,520,860);
	}
	
	public void onDraw(Canvas c){
		c.drawBitmap(grid, gridsrc, griddest, p);
		c.drawText("width="+getWidth()+" height ="+getHeight(), 40, 140, p);
		invalidate();
	}
	
}
