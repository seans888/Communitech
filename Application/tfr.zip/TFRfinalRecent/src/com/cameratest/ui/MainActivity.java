package com.cameratest.ui;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.camera.util.Log;

/**
 * Gives a simple UI that detects if this device has a camera,
 * informing the user if they do or dont
 *
 * This also receives the result of a picture being taken and displays it to the user
 *
 * @author paul.blundell
 *
 */


public class MainActivity extends Activity  {

    private static final int REQ_CAMERA_IMAGE = 123;
    Bitmap myBitmap,bmpRotate;
    Intent anotherintent;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        String message = null;
        if(cameraNotDetected()){
        	message = "No camera detected, clicking the button below will have unexpected behaviour.";
        }
        TextView cameraDescriptionTextView = (TextView) findViewById(R.id.text_view_camera_description);
        cameraDescriptionTextView.setText(message);
    }

    private boolean cameraNotDetected() {
		return !getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA);
	}

    public void onUseCameraClick(View button){
    	Intent intent = new Intent(this, CameraActivity.class);
    	startActivityForResult(intent, REQ_CAMERA_IMAGE);
    }

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(requestCode == REQ_CAMERA_IMAGE && resultCode == RESULT_OK){
			String imgPath = data.getStringExtra(CameraActivity.EXTRA_IMAGE_PATH);
			Log.i("Got image path: "+ imgPath);
			displayImage(imgPath);
		} else
		if(requestCode == REQ_CAMERA_IMAGE && resultCode == RESULT_CANCELED){
			Log.i("User didn't take an image");
		}
	}
	
	public void edit(View v){
		File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "TFR");
		String timeStamp = new SimpleDateFormat("yyyyMMdd").format(new Date());
		String path = mediaStorageDir.getPath() + File.separator +"IMG_"+ timeStamp +".jpg";
		anotherintent = new Intent(this, FittingRoom.class);
		SharedPreferences sp = getSharedPreferences("setting", MODE_PRIVATE);
		SharedPreferences.Editor edit = sp.edit();
		edit.putString("ipath",path);
		edit.commit();
	    startActivity(anotherintent);
	}
	
	/*public Bitmap overlayMark() 
	{ 
		Bitmap grid = BitmapFactory.decodeResource(getResources(), R.drawable.gridoverlay);
	    Bitmap bmOverlay = Bitmap.createBitmap(bmpRotate.getWidth(), bmpRotate.getHeight(), bmpRotate.getConfig()); 
	    Canvas canvas = new Canvas(bmOverlay); 
	    canvas.drawBitmap(bmpRotate, 0, 0, null);
	    canvas.drawBitmap(grid, 150, 150, null);
	    return bmOverlay; 
	}*/ 
	public void back(View v){
		Intent intent = new Intent(this, Main.class);
		startActivity(intent);
	}

	public void displayImage(String path) {
		/*File imgfile = new File(path);
		myBitmap = BitmapFactory.decodeFile(imgfile.getAbsolutePath());
		ImageView imageView = (ImageView) findViewById(R.id.image_view_captured_image);
		//imageView1.setImageBitmap(myBitmap);
		Matrix matrix = new Matrix();
		matrix.setRotate(90);
		bmpRotate = Bitmap.createBitmap(myBitmap, 0, 0, myBitmap.getWidth(), myBitmap.getHeight(), matrix, true);
		imageView.setImageBitmap(bmpRotate);*/
		edit(null);
	}
}